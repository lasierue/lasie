from datetime import datetime
from flask import Flask, render_template, request
import data

app = Flask(__name__)
data.create_tables()

@app.route("/", methods=["GET","POST"])
def home():
        
        if request.method == "POST":
            entry_content=request.form.get("content")
            data.create_entry(entry_content, datetime.now().strftime("%m/%d/%Y"))
            
        
        return render_template("home.html", entries = data.retrive_entries())

app.run()
            